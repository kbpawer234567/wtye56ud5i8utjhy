// content.js

function setBackground() {
    chrome.storage.local.get(['backgroundUrl'], function(result) {
        const backgroundUrl = result.backgroundUrl;
        if (backgroundUrl) {
            // Retry until custom-background element is found
            const backgroundDiv = document.querySelector('.custom-background');
            if (backgroundDiv) {
                backgroundDiv.style.backgroundImage = `url(${backgroundUrl})`;
                console.log("Background image applied:", backgroundUrl);  // Log for debugging
            } else {
                console.log("custom-background element not found, retrying...");
                setTimeout(setBackground, 500);  // Retry every 500ms
            }
        } else {
            console.log("No background image found in storage.");
        }
    });
}

window.addEventListener('load', setBackground);
// content.js
window.addEventListener('load', function() {
  chrome.storage.local.get(['backgroundUrl'], function(result) {
    const backgroundUrl = result.backgroundUrl;

    if (backgroundUrl) {
      const backgroundDiv = document.querySelector('.custom-background');
      if (backgroundDiv) {
        backgroundDiv.style.backgroundImage = `url(${backgroundUrl})`;
      }
    }
  });
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.color) {
        const elements = document.querySelectorAll('h1, h2, h3, h4, h5, h6, p, span, a, li');
        elements.forEach((el) => {
            el.style.color = request.color;
        });
    }
});
// Function to replace the avatar div
function replaceAvatar() {
    const avatarDivs = document.querySelectorAll('div.avatar-content.overflow-hidden[style="height: 40px; width: 40px;"]');
    
    avatarDivs.forEach(div => {
        div.innerHTML = '<img src="https://lh6.googleusercontent.com/_1k-NED-nVgrlDDdG9ukzvLqfBO6XkJbkg_AI7uzySHkYnPVd-hiLHO1K-X4MBtavK2GXvv6caUrOe0IwDaGLEUAts3c6gkt2XBHSZeFtr73KOrH1FaRCOkOJMR9ZHDjTQ=w1280">';
    });
}

// Run the replace function when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', replaceAvatar);


