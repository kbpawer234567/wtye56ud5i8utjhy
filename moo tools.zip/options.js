// Get DOM elements
const fileInput = document.getElementById('background-upload');
const previewDiv = document.getElementById('background-preview');
const saveButton = document.getElementById('save-button');

// Event listener for file input
fileInput.addEventListener('change', function(event) {
  const file = event.target.files[0];

  // If a file is selected, display the preview and enable the save button
  if (file) {
    const reader = new FileReader();

    reader.onload = function(e) {
      // Display the image preview
      previewDiv.style.backgroundImage = `url(${e.target.result})`;
      previewDiv.textContent = ''; // Clear the "No Image Selected" text

      // Enable the save button
      saveButton.disabled = false;
      saveButton.textContent = 'Save Background';
    };

    reader.readAsDataURL(file);
  } else {
    // Reset preview and disable save button if no file is selected
    previewDiv.style.backgroundImage = '';
    previewDiv.textContent = 'No Image Selected';
    saveButton.disabled = true;
  }
});

// Event listener for save button
saveButton.addEventListener('click', function() {
  const backgroundUrl = previewDiv.style.backgroundImage.slice(5, -2); // Remove "url(" and ")"
  
  if (backgroundUrl) {
    // Save the background URL to chrome.storage
    chrome.storage.local.set({ backgroundUrl: backgroundUrl }, function() {
      // Change the button text to 'Saved'
      saveButton.textContent = 'Saved';

      // Ensure that background is applied and reload the page
      window.location.reload(); // Force the page to reload
    });
  }
});

