// popup.js
document.getElementById("fileInput").addEventListener("change", function(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            // Save the background image URL in chrome.storage
            chrome.storage.local.set({ backgroundImage: e.target.result }, () => {
                // Apply the background to the current page immediately after upload
                chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                    chrome.scripting.executeScript({
                        target: { tabId: tabs[0].id },
                        func: applyBackground,
                        args: [e.target.result]
                    });
                });
            });
        };
        reader.readAsDataURL(file);
    }
});

// Function to apply the background image in the page
function applyBackground(imageUrl) {
    let targetDiv = document.querySelector("app-background div.custom-background");
    if (targetDiv) {
        targetDiv.style.backgroundImage = `url('${imageUrl}')`;
    }
}
